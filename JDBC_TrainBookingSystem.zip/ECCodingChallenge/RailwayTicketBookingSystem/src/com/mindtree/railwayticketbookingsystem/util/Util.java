package com.mindtree.railwayticketbookingsystem.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mindtree.railwayticketbookingsystem.exception.dao.DAOException;

public class Util {
	static Connection con = null;
	static final String url = "jdbc:mysql://localhost:3306/trainfaregenerator?useSSL=false";
	static final String un = "root";
	static final String pwd = "Welcome123";

	public Util() {
	}

	public Connection getConnection() throws DAOException  {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(url, un, pwd);
		} catch (SQLException | ClassNotFoundException e) {
			throw new DAOException("Error Creating Connection", e);
		}
		return con;
	}

	public void closeConnection() throws DAOException {
		try {
			con.close();
		} catch (SQLException e) {
			throw new DAOException("Error Closing Connection", e);
		}
	}

}
