package com.mindtree.railwayticketbookingsystem.client;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import com.mindtree.railwayticketbookingsystem.entity.Train;
import com.mindtree.railwayticketbookingsystem.entity.User;
import com.mindtree.railwayticketbookingsystem.exception.client.ClientException;
import com.mindtree.railwayticketbookingsystem.exception.service.ServiceEcxeption;
import com.mindtree.railwayticketbookingsystem.service.RailwayTicketBookingService;
import com.mindtree.railwayticketbookingsystem.service.impl.RailwayTicketBookingImpl;

public class RailwayTicketBookingApp {
	static Scanner scan = new Scanner(System.in);
	static RailwayTicketBookingService railwayTicketBookingService = new RailwayTicketBookingImpl();

	public static void main(String[] args) {

		int opt;
		do {
			System.out.println("1. BOOK A TICKET\n" + "2. SORT BOOKINGS BASED ON FARE\n"
					+ "3. WRITE THE DETAILS IN A FILE\n" + "4. Exit" + "ENTER YOUR CHOICE: ");
			opt = scan.nextInt();
			switch (opt) {
			case 1:
				try {
					bookTicket();
				} catch (ClientException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					sortBookings();
				} catch (ClientException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					writeInFile();
				} catch (ClientException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				break;

			default:

				break;
			}
		} while (opt != 4);

	}

	private static void writeInFile() throws ClientException {
		System.out.println("Writing the details of bookings to a file:");
		System.out.println("Enter the userID to writr his details in file:");
		int userId = scan.nextInt();
		try {
			int done = railwayTicketBookingService.writeInFile(userId);
		} catch (ServiceEcxeption e) {
			// TODO Auto-generated catch block
			throw new ClientException("There is an error in client",e);
		}

	}

	private static void sortBookings() throws ClientException {
		Map<Integer, User> bookingDetails = new TreeMap<Integer, User>();
		System.out.println("Tnter the trainId: ");
		int trainId = scan.nextInt();
		try {
			class MyCopr implements Comparator<String>{
				 
			    @Override
			    public int compare(String str1, String str2) {
			        return str1.compareTo(str2);
			    }
			     
			}
			bookingDetails = railwayTicketBookingService.sortBookings(trainId);
			System.out.println("The booking details in sorting order are: ");
			System.out.println(bookingDetails);
			
		} catch (ServiceEcxeption e) {
			// TODO Auto-generated catch block
			throw new ClientException("There is an error in client",e);
		}
		

	}

	private static void bookTicket() throws ClientException {
		scan.nextLine();
		HashSet<Train> trains = new HashSet<>();
		System.out.println("Enter the Source:");
		String source = scan.nextLine();
		System.out.println("Enter the Destination");
		String destination = scan.nextLine();
		try {
			trains = railwayTicketBookingService.displayTrains(source, destination);
		} catch (ServiceEcxeption e) {
			// TODO Auto-generated catch block
			throw new ClientException("There is an error in client",e);
		}
		System.out.println("Available trains between " + source + " and " + destination + " are:");
		System.out.println(trains);

		System.out.println("Enter the Train ID: ");
		int trainId = scan.nextInt();

		System.out.println("Enter the User ID: ");
		int userId = scan.nextInt();
		
		try {
			int fare = railwayTicketBookingService.addBooking(trainId,userId);
			System.out.println("Booking Successful and calculated fare is "+fare);
		} catch (ServiceEcxeption e) {
			// TODO Auto-generated catch block
			throw new ClientException("There is an error in client",e);
		}

	}
}
