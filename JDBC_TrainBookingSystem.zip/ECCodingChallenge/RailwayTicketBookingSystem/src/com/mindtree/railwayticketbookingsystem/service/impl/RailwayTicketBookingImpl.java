package com.mindtree.railwayticketbookingsystem.service.impl;

import java.util.HashSet;
import java.util.Map;

import com.mindtree.railwayticketbookingsystem.dao.RailwayBookingDao;
import com.mindtree.railwayticketbookingsystem.dao.impl.RailwayBookingDaoImpl;
import com.mindtree.railwayticketbookingsystem.entity.Train;
import com.mindtree.railwayticketbookingsystem.entity.User;
import com.mindtree.railwayticketbookingsystem.exception.dao.DAOException;
import com.mindtree.railwayticketbookingsystem.exception.dao.NoSuchSourceDestinationException;
import com.mindtree.railwayticketbookingsystem.exception.dao.NoSuchSourceException;
import com.mindtree.railwayticketbookingsystem.exception.service.ServiceEcxeption;
import com.mindtree.railwayticketbookingsystem.service.RailwayTicketBookingService;

public class RailwayTicketBookingImpl implements RailwayTicketBookingService{
	RailwayBookingDao railwayBookingDao = new RailwayBookingDaoImpl();
	@Override
	public HashSet<Train> displayTrains(String source, String destination) throws ServiceEcxeption {
		
		try {
			return railwayBookingDao.displayTrains(source,destination);
		} catch (DAOException | NoSuchSourceException | NoSuchSourceDestinationException e) {
			throw new ServiceEcxeption("There is an error in Service",e);
		}
	}

	@Override
	public int addBooking(int trainId, int userId) throws ServiceEcxeption {
		// TODO Auto-generated method stub
		try {
			return railwayBookingDao.addBooking(trainId,userId);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			throw new ServiceEcxeption("There is an error in Service",e);
		}
	}

	@Override
	public Map<Integer, User> sortBookings(int trainId) throws ServiceEcxeption {
		// TODO Auto-generated method stub
		try {
			return railwayBookingDao.sortBookings(trainId);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			throw new ServiceEcxeption("There is an error in Service",e);
		}
	}

	@Override
	public int writeInFile(int userId) throws ServiceEcxeption {
		// TODO Auto-generated method stub
		try {
			return railwayBookingDao.writeFile(userId);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			throw new ServiceEcxeption("There is an error in Service",e);
		}
	}

}
