package com.mindtree.railwayticketbookingsystem.service;

import java.util.HashSet;
import java.util.Map;

import com.mindtree.railwayticketbookingsystem.entity.Train;
import com.mindtree.railwayticketbookingsystem.entity.User;
import com.mindtree.railwayticketbookingsystem.exception.service.ServiceEcxeption;

public interface RailwayTicketBookingService {

	HashSet<Train> displayTrains(String source, String destination) throws ServiceEcxeption;

	int addBooking(int trainId, int userId) throws ServiceEcxeption;

	Map<Integer, User> sortBookings(int trainId) throws ServiceEcxeption;

	int writeInFile(int userId) throws ServiceEcxeption;

}
