package com.mindtree.railwayticketbookingsystem.dao.impl;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeMap;

import com.mindtree.railwayticketbookingsystem.dao.RailwayBookingDao;
import com.mindtree.railwayticketbookingsystem.entity.Train;
import com.mindtree.railwayticketbookingsystem.entity.User;
import com.mindtree.railwayticketbookingsystem.util.Util;
import com.mindtree.railwayticketbookingsystem.exception.dao.DAOException;
import com.mindtree.railwayticketbookingsystem.exception.dao.NoSuchSourceDestinationException;
import com.mindtree.railwayticketbookingsystem.exception.dao.NoSuchSourceException;

public class RailwayBookingDaoImpl implements RailwayBookingDao {

	Util util = new Util();
	HashSet<Train> trains = new HashSet<>();

	@Override
	public HashSet<Train> displayTrains(String source, String destination)
			throws DAOException, NoSuchSourceException, NoSuchSourceDestinationException {
		try {

			Connection con = util.getConnection();
			PreparedStatement preparedStatement = con
					.prepareStatement("select * from train where source_name=? and dest_name=?");
			preparedStatement.setString(1, source);
			preparedStatement.setString(2, destination);
			ResultSet rs = preparedStatement.executeQuery();
			try {
				if (checkSource(source)) {
					try {
						if (checkDest(destination)) {
							while (rs.next()) {
								Train train = new Train();
								train.setTrainId(rs.getInt(1));
								train.setTrainName(rs.getString(2));
								train.setSource(rs.getString(3));
								train.setDestination(rs.getString(4));
								train.setDistance(rs.getInt(5));
								trains.add(train);

							}
						}

					} catch (Exception e) {
						throw new NoSuchSourceDestinationException("Destination not exixts!", e);
					}

				}
			} catch (Exception e) {
				throw new NoSuchSourceException("SourceNot Exixts", e);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return trains;

	}

	@Override
	public int addBooking(int trainId, int userId) throws DAOException {
		int fare = 0;
		try {
			Connection con = util.getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("select distance from train where train_id=?");
			preparedStatement.setInt(1, trainId);
			ResultSet distance = preparedStatement.executeQuery();
			distance.next();
			fare = distance.getInt(1) * 10;

			PreparedStatement preparedStatement2 = con.prepareStatement("insert into booking values(?,?,?)");
			preparedStatement2.setInt(1, userId);
			preparedStatement2.setInt(2, trainId);
			preparedStatement2.setInt(3, fare);

			preparedStatement2.executeUpdate();

		} catch (SQLException e) {
			// TODO: handle exception
		}
		return fare;
	}

	@Override
	public Map<Integer, User> sortBookings(int trainId) throws DAOException {
		Map<Integer, User> bookingDetails = new TreeMap<Integer, User>();
		int fare = 0;
		try {
			Connection con = util.getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("select distance from train where train_id=?");
			preparedStatement.setInt(1, trainId);
			ResultSet distance = preparedStatement.executeQuery();
			distance.next();
			fare = distance.getInt(1) * 10;

			PreparedStatement preparedStatement2 = con.prepareStatement(
					"select user_id,user_name from user join booking on user.user_id=booking.user_ref_id where train_ref_id=?");
			preparedStatement2.setInt(1, trainId);
			ResultSet rs = preparedStatement2.executeQuery();
			User user = new User();
			while (rs.next()) {
				user=new User(); 
				user.setUserId(rs.getInt(1));

				user.setUserName(rs.getString(2));

				bookingDetails.put(fare, user);

			}

		} catch (SQLException e) {
			// TODO: handle exception
		}
		return bookingDetails;
	}

	@Override
	public int writeFile(int userId) throws DAOException {
		try {
			Connection con = util.getConnection();
			PreparedStatement preparedStatement = con.prepareStatement(
					"select train.train_id,train.train_name,train.source_name,train.dest_name,train.distance,booking.fare,user.user_name from train join booking on train.train_id=booking.train_ref_id join user on booking.user_ref_id=user.user_id where booking.user_ref_id=?");
			preparedStatement.setInt(1, userId);
			ResultSet rs = preparedStatement.executeQuery();
			FileWriter fileWriter = new FileWriter("C:\\Users\\M1056135\\Desktop\\BookingDetails.txt", true);
			BufferedWriter out = new BufferedWriter(fileWriter);
			out.write("trainID  TrainName  Source  Destination  Distance  Fare  UserName\n");
			String str = "";
			while (rs.next()) {
				str = rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3) + "  " + rs.getString(4) + "  "
						+ rs.getInt(5) + "  " + rs.getInt(6) + "  " + rs.getString(7) + "\n";
				out.write(str);
				out.close();
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
		return 1;
	}

	@Override
	public boolean checkSource(String source) throws DAOException {
		boolean check = false;
		try {
			Connection con = util.getConnection();
			PreparedStatement preparedStatement = con
					.prepareStatement("select source_name from train where source_name=?");
			preparedStatement.setString(1, source);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.first()) {
				check = true;

			}

		} catch (SQLException e) {
			// TODO: handle exception
		}
		if (check) {

			return true;
		} else
			return false;
	}

	@Override
	public boolean checkDest(String destination) throws DAOException {
		boolean check = false;
		try {
			Connection con = util.getConnection();
			PreparedStatement preparedStatement = con.prepareStatement("select dest_name from train where dest_name=?");
			preparedStatement.setString(1, destination);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.first()) {
				check = true;

			}

		} catch (SQLException e) {
			// TODO: handle exception
		}
		if (check) {

			return true;
		} else
			return false;
	}

}
