package com.mindtree.railwayticketbookingsystem.dao;

import java.util.HashSet;
import java.util.Map;

import com.mindtree.railwayticketbookingsystem.entity.Train;
import com.mindtree.railwayticketbookingsystem.entity.User;
import com.mindtree.railwayticketbookingsystem.exception.dao.DAOException;
import com.mindtree.railwayticketbookingsystem.exception.dao.NoSuchSourceDestinationException;
import com.mindtree.railwayticketbookingsystem.exception.dao.NoSuchSourceException;

public interface RailwayBookingDao {

	HashSet<Train> displayTrains(String source, String destination) throws DAOException, NoSuchSourceException, NoSuchSourceDestinationException;

	int addBooking(int trainId, int userId) throws DAOException;

	Map<Integer, User> sortBookings(int trainId) throws DAOException;

	int writeFile(int userId) throws DAOException;

	boolean checkSource(String source) throws DAOException;

	boolean checkDest(String destination) throws DAOException;

}
