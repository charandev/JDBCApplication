package com.mindtree.railwayticketbookingsystem.exception.service;

import com.mindtree.railwayticketbookingsystem.exception.ApplicationException;

public class ServiceEcxeption extends ApplicationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiceEcxeption() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceEcxeption(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public ServiceEcxeption(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ServiceEcxeption(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public ServiceEcxeption(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
