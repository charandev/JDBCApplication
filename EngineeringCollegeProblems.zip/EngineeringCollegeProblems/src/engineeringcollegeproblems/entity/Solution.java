package engineeringcollegeproblems.entity;

public class Solution {
	private int solutionId;
	private String solutionDesc;
	public Solution(int solutionId, String solutionDesc) {
		super();
		this.solutionId = solutionId;
		this.solutionDesc = solutionDesc;
	}
	public Solution() {
		super();
	}
	public int getSolutionId() {
		return solutionId;
	}
	public void setSolutionId(int solutionId) {
		this.solutionId = solutionId;
	}
	public String getSolutionDesc() {
		return solutionDesc;
	}
	public void setSolutionDesc(String solutionDesc) {
		this.solutionDesc = solutionDesc;
	}
	@Override
	public String toString() {
		return "Solution [solutionId=" + solutionId + ", solutionDesc=" + solutionDesc + "]";
	}
	
	
}
