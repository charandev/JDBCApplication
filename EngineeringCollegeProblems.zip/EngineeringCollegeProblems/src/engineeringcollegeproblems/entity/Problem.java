package engineeringcollegeproblems.entity;

public class Problem {
	private int problemId;
	private String problemName;
	private String problemDesc;
	public Problem(int problemId, String problemName, String problemDesc) {
		super();
		this.problemId = problemId;
		this.problemName = problemName;
		this.problemDesc = problemDesc;
	}
	public Problem() {
		super();
	}
	public int getProblemId() {
		return problemId;
	}
	public void setProblemId(int problemId) {
		this.problemId = problemId;
	}
	public String getProblemName() {
		return problemName;
	}
	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}
	public String getProblemDesc() {
		return problemDesc;
	}
	public void setProblemDesc(String problemDesc) {
		this.problemDesc = problemDesc;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((problemDesc == null) ? 0 : problemDesc.hashCode());
		result = prime * result + problemId;
		result = prime * result + ((problemName == null) ? 0 : problemName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Problem other = (Problem) obj;
		if (problemDesc == null) {
			if (other.problemDesc != null)
				return false;
		} else if (!problemDesc.equals(other.problemDesc))
			return false;
		if (problemId != other.problemId)
			return false;
		if (problemName == null) {
			if (other.problemName != null)
				return false;
		} else if (!problemName.equals(other.problemName))
			return false;
		return true;
	}
	
	
}
