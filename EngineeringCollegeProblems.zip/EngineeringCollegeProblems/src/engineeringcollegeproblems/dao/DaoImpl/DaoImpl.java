package engineeringcollegeproblems.dao.DaoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import engineeringcollegeproblems.dao.Dao;
import engineeringcollegeproblems.entity.Solution;
import engineeringcollegeproblems.exception.DAOExeption;
import engineeringcollegeproblems.util.Util;

public class DaoImpl implements Dao {
	Util util = new Util();

	@Override
	public Solution addSolutions(Solution solution) throws DAOExeption, SQLException {
		Connection con = util.getConnection();
		PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO solution VALUES(?,?)");
		preparedStatement.setInt(1, solution.getSolutionId());
		preparedStatement.setString(2, solution.getSolutionDesc());

		preparedStatement.executeUpdate();
		util.closeConnection();
		return solution;
	}

	@Override
	public String categoriseProblem(int categoryId, int problemId) throws DAOExeption, SQLException {
		Connection con = util.getConnection();
		PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO problemcategory VALUES(?,?)");
		preparedStatement.setInt(2, categoryId);
		preparedStatement.setInt(1, problemId);

		preparedStatement.executeUpdate();
		util.closeConnection();
		return null;
	}

	@Override
	public int assignSolutions(int problemId, int solutionId) throws DAOExeption, SQLException {
		Connection con = util.getConnection();
		PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO problemsolution VALUES(?,?)");
		preparedStatement.setInt(1, problemId);
		preparedStatement.setInt(2, solutionId);
		preparedStatement.executeUpdate();
		util.closeConnection();
		return problemId;
	}

	@Override
	public ArrayList<String> displayProblemsOnSolution(int solutionId) throws DAOExeption, SQLException {
		ArrayList<String> problems = new ArrayList<>();
		Connection con = util.getConnection();
		PreparedStatement preparedStatement = con.prepareStatement(
				"select problem.problem_name from problem join problemsolution on problem.problem_id=problemsolution.problem_ref_id join solution on problemsolution.solution_ref_id=solution.solution_id where solution_id=?");
		preparedStatement.setInt(1, solutionId);
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next()) {
			problems.add(rs.getString(1));
		}
		util.closeConnection();
		return problems;
	}

	@Override
	public ArrayList<String> displayProblemsOnCategory(int categoryId) throws DAOExeption, SQLException {
		ArrayList<String> problems = new ArrayList<>();
		Connection con = util.getConnection();
		PreparedStatement preparedStatement = con.prepareStatement("select problem.problem_name from problem join problemcategory on problem.problem_id=problemcategory.problem_ref_id join category on problemcategory.category_ref_id=category.category_id where category_id=?");
		preparedStatement.setInt(1, categoryId);
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next()) {
			problems.add(rs.getString(1));
		}
		util.closeConnection();
		return problems;
	
		
	}

	@Override
	public ArrayList<String> sortProblems() throws DAOExeption, SQLException {
		ArrayList<String> problems = new ArrayList<>();
		Connection con = util.getConnection();
		PreparedStatement preparedStatement = con.prepareStatement("select problem.problem_name from problem join problemsolution on problem.problem_id=problemsolution.problem_ref_id join solution on problemsolution.solution_ref_id=solution.solution_id group by solution.solution_id order by solution.solution_id");
		
		ResultSet rs = preparedStatement.executeQuery();
		while(rs.next()) {
			problems.add(rs.getString(1));
		}
		util.closeConnection();
		return problems;
	}

}
