package engineeringcollegeproblems.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import engineeringcollegeproblems.entity.Solution;
import engineeringcollegeproblems.exception.DAOExeption;

public interface Dao {

	Solution addSolutions(Solution solution) throws DAOExeption, SQLException;

	String categoriseProblem(int categoryId, int problemId) throws DAOExeption, SQLException;

	int assignSolutions(int problemId, int solutionId) throws DAOExeption, SQLException;

	ArrayList<String> displayProblemsOnSolution(int solutionId) throws DAOExeption, SQLException;

	ArrayList<String> displayProblemsOnCategory(int catigoryId) throws DAOExeption, SQLException;

	ArrayList<String> sortProblems() throws DAOExeption, SQLException;

}
