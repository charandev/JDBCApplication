package engineeringcollegeproblems.service.EngineeringCollegeImpl;

import java.sql.SQLException;
import java.util.ArrayList;

import engineeringcollegeproblems.dao.Dao;
import engineeringcollegeproblems.dao.DaoImpl.DaoImpl;
import engineeringcollegeproblems.entity.Solution;
import engineeringcollegeproblems.exception.DAOExeption;
import engineeringcollegeproblems.exception.InvalidCategoryException;
import engineeringcollegeproblems.service.EngineeringCollegeService;

public class EngineeringCollegeImpl implements EngineeringCollegeService {
	Dao dao = new DaoImpl();

	@Override
	public Solution addSolutions(Solution solution) throws DAOExeption, SQLException {

		return dao.addSolutions(solution);
	}

	@Override
	public String categoriseProblem(int categoryId, int problemId)
			throws InvalidCategoryException, DAOExeption, SQLException {

		return dao.categoriseProblem(categoryId, problemId);

	}

	@Override
	public int assignSolutions(int problemId, int solutionId) throws DAOExeption, SQLException {

		return dao.assignSolutions(problemId, solutionId);
	}

	@Override
	public ArrayList<String> displayProblemsOnSolution(int solutionId) throws DAOExeption, SQLException {

		return dao.displayProblemsOnSolution(solutionId);
	}

	@Override
	public ArrayList<String> displayProblemsOnCategory(int catigoryId) throws DAOExeption, SQLException {
		
		return dao.displayProblemsOnCategory(catigoryId);
	}

	@Override
	public ArrayList<String> sortProblems() throws DAOExeption, SQLException {
		// TODO Auto-generated method stub
		return dao.sortProblems();
	}

}
