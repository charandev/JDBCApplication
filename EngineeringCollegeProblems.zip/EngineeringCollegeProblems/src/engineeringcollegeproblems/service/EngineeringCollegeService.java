package engineeringcollegeproblems.service;

import java.sql.SQLException;
import java.util.ArrayList;

import engineeringcollegeproblems.entity.Solution;
import engineeringcollegeproblems.exception.DAOExeption;
import engineeringcollegeproblems.exception.InvalidCategoryException;

public interface EngineeringCollegeService {

	Solution addSolutions(Solution solution) throws DAOExeption, SQLException;

	String categoriseProblem(int categoryId, int problemId) throws InvalidCategoryException, DAOExeption, SQLException;

	int assignSolutions(int problemId, int solutionId) throws DAOExeption, SQLException;

	ArrayList<String> displayProblemsOnSolution(int solutionId) throws DAOExeption, SQLException;

	ArrayList<String> displayProblemsOnCategory(int catigoryId) throws DAOExeption, SQLException;

	ArrayList<String> sortProblems() throws DAOExeption, SQLException;

}
