package engineeringcollegeproblems.client;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import engineeringcollegeproblems.entity.Solution;
import engineeringcollegeproblems.exception.DAOExeption;
import engineeringcollegeproblems.exception.InvalidCategoryException;
import engineeringcollegeproblems.service.EngineeringCollegeService;
import engineeringcollegeproblems.service.EngineeringCollegeImpl.EngineeringCollegeImpl;

public class EngineeringCollegeApp {
	static Scanner scan = new Scanner(System.in);
	static EngineeringCollegeService engineeringCollegeService = new EngineeringCollegeImpl();

	public static void main(String[] args) {
		int opt;
		do {
			System.out
					.println("1. Add solutions\n" + "2. Categorize problem.\n" + "3. Assign Solutions to the problem.\n"
							+ "4. Display all problem details having a particular category.\n"
							+ "5. Enter a solution and display all problems having that solution.\n"
							+ "6. Sort problems based on number of solutions.\n" + "7. Exit");

			opt = scan.nextInt();

			switch (opt) {
			case 1:
				addSolutions();
				break;
			case 2:
				try {
					categoriseProblem();
				} catch (InvalidCategoryException | DAOExeption | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					assignSolutions();
				} catch (DAOExeption e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 4:
				try {
					displayProblemsOnCategory();
				} catch (DAOExeption e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				break;
			case 5:
				try {
					displayProblemsOnSolution();
				} catch (DAOExeption e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 6:
				try {
					sortProblems();
				} catch (DAOExeption e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			}
		} while (opt != 6);
	}

	private static void sortProblems() throws DAOExeption, SQLException {
		System.out.println("The list of problems based on number of solutions are:");
		System.out.println(engineeringCollegeService.sortProblems());

	}

	private static void displayProblemsOnSolution() throws DAOExeption, SQLException {
		// TODO Auto-generated method stub
		System.out.println("Enter the solution ID to fetch details of problems:");
		int solutionId = scan.nextInt();
		ArrayList<String> problems = engineeringCollegeService.displayProblemsOnSolution(solutionId);
		System.out.println(problems);

	}

	private static void displayProblemsOnCategory() throws DAOExeption, SQLException {
		System.out.println("Enter the catogiry ID to fetch the details of problems:");
		int catigoryId = scan.nextInt();
		ArrayList<String> problem = engineeringCollegeService.displayProblemsOnCategory(catigoryId);
		System.out.println(problem);
	}

	private static void assignSolutions() throws DAOExeption, SQLException {
		// scan.nextLine();
		System.out.println("Enter the porblem Id to assign a solution:");
		int problemId = scan.nextInt();
		System.out.println("Enter the solution ID to assign to thta problem:");
		int solutionId = scan.nextInt();
		int check = engineeringCollegeService.assignSolutions(problemId, solutionId);

	}

	private static void categoriseProblem() throws InvalidCategoryException, DAOExeption, SQLException {
		System.out.println("Entre the category ID:");
		int categoryId = scan.nextInt();
		System.out.println("Entre the problem ID to set catogory:");
		int problemId = scan.nextInt();
		scan.nextLine();
//		System.out.println("Enter the category:(serius/seasonal/casual)");
//		String categoryName = scan.nextLine();

		String category = engineeringCollegeService.categoriseProblem(categoryId, problemId);
		System.out.println(category + " Added");

	}

	private static void addSolutions() {
		Solution solution = new Solution();

		System.out.println("Enter the solution ID:");
		int solutionId = scan.nextInt();
		scan.nextLine();
		solution.setSolutionId(solutionId);
		System.out.println("Enter the solution Description:");
		String solutionDesc = scan.nextLine();
		solution.setSolutionDesc(solutionDesc);
		try {
			System.out.println(engineeringCollegeService.addSolutions(solution));
		} catch (DAOExeption | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
